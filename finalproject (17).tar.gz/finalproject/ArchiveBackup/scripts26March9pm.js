/**
 * scripts.js
 *
 * Computer Science 50
 * Final Project - CS-50hz
 *
 * Global JavaScript.
 */

//update graph
function graph()
{
    var binnum = 64; //number of bins to calculate and display
    var smoothing = 0.80; //smoothing rate 0.8 is default
    var binwidth = 0.95; //Width of bins or graph bars. 1 is full width, 0 is hidden
    //Add coulours for gradient
    //add crossover point for gradient
    
    
    
    createcanvas(); //Load canvas. Also load if window resised
    window.onresize = function() {createcanvas();};

    //Audio context required for any audio work. Creates and manages nodes
    var context = new AudioContext();
    
    //Audio analyser
    var analyser = context.createAnalyser();
        //Fourier transform size (Number of bins per channel?)
        analyser.fftSize = binnum * 2;
        //Smooth samples 0.8 is default
        analyser.smoothingTimeConstant = smoothing;
    var frequencyData = new Uint8Array( analyser.fftSize );

    var mediaStreamSource;
        navigator.getUserMedia = (navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia);
        navigator.getUserMedia(
            { audio: true }, 
            function( stream ) {
                mediaStreamSource = context.createMediaStreamSource( stream );
                mediaStreamSource.connect( analyser );
            }, 
            function( e ) {
                console.log( 'getUserMedia ' + e );
            }
    );
        
    update();

    //update plot
    function update() {
        requestAnimationFrame( update );
        analyser.getByteFrequencyData( frequencyData );
        ctx.clearRect( 0, 0, canvas.width, canvas.height );
        ctx.fillStyle=gradient;
        for( var i = 0, j = analyser.frequencyBinCount; i < j; i++ ) {
            //frequency bin count is 128 as of 26/3/16 USB webcam with microscope on Chrome and win7
            //fill rectangle (top left X position, top left y position, width, height)
            ctx.fillRect( i * ( canvas.width / j ), canvas.height, binwidth * canvas.width / j, - frequencyData[ i ] * canvas.height / 255 );
    	 }
    }
    
    //Creates the canvas based on the window size. New gradient required and ctx updated
    function createcanvas(){
        canvas.width = document.documentElement.clientWidth * 0.99;
        canvas.height = document.documentElement.clientHeight * 0.98; //0.98 stops the scroll bar showing
        //get the context from the canvas to draw on
        ctx = $("#canvas").get()[0].getContext("2d");
        //create a gradient for the fill. Note the strange offset, since the gradient is calculated based on the canvas, not the specific element we draw
        gradient = ctx.createLinearGradient(0,0,0,canvas.height);
        gradient.addColorStop(1,'#000000');
        gradient.addColorStop(0.50,'#00FF00');
        gradient.addColorStop(0.10,'#FF0000');
    }

    
}


//toggle info on and off
$(document).ready(function() {
    $('#infobutton').click(function(event) {
        $('#info').toggle();
    });
});
