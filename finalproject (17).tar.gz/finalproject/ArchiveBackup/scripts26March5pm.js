/**
 * scripts.js
 *
 * Computer Science 50
 * Final Project - CS-50hz
 *
 * Global JavaScript.
 */

//<button> About CS-50hz </button>



//update graph
function graph()
{
    
    //Initial values until loaded. then canvassize will be called
    canvassize();
    window.onresize = function() {canvassize();};
    
    //Audio context required for any audio work. Creates and manages nodes
    var context = new AudioContext();
    
    var analyser = context.createAnalyser();
        analyser.fftSize = 256;
        analyser.smoothingTimeConstant = .75;
    var frequencyData = new Uint8Array( analyser.fftSize );

    // get the context from the canvas to draw on
    var ctx = $("#canvas").get()[0].getContext("2d");
    console.log(ctx);
    
    // create a gradient for the fill. Note the strange offset, since the gradient is calculated based on the canvas, not the specific element we draw
    var gradient = ctx.createLinearGradient(0,0,0,canvas.height);
    gradient.addColorStop(1,'#000000');
    gradient.addColorStop(0.75,'#ff0000');
    gradient.addColorStop(0.25,'#ffff00');
    gradient.addColorStop(0,'#ffffff');

    var mediaStreamSource;
        navigator.getUserMedia = ( navigator.getUserMedia
                               || navigator.webkitGetUserMedia 
                               || navigator.mozGetUserMedia 
                               || navigator.msGetUserMedia );
        navigator.getUserMedia(
	        { audio: true }, 
	        function( stream ) {
	    	    mediaStreamSource = context.createMediaStreamSource( stream );
    		    mediaStreamSource.connect( analyser );
	        }, 
	        function( e ) {
		        console.log( 'getUserMedia ' + e );
	        }
        );
        
    update();
    
    
    function update() {
	    requestAnimationFrame( update );
    	analyser.getByteFrequencyData( frequencyData );
	    ctx.clearRect( 0, 0, canvas.width, canvas.height );
	    ctx.fillStyle=gradient;
	    for( var i = 0, j = analyser.frequencyBinCount; i < j; i++ ) {
	        //frequency bin count is 128 as of 26/3/16 USB webcam with microscope on Chrome and win7
	        //fill rectangle (top left X position, top left y position, widht, height)
		    ctx.fillRect( i * ( canvas.width / j ), canvas.height, .5 * canvas.width / j, - frequencyData[ i ] * canvas.height / 255 );
	    }
	    
    }

    function canvassize(){
        canvas.width = document.documentElement.clientWidth;
        canvas.height = 900;
    }
    
}


