/**
 * scripts.js
 *
 * Computer Science 50
 * Final Project - CS-50hz
 *
 * Global JavaScript.
 */

//update graph
function graph()
{
    var binnum = 1024; //number of bins to calculate
    var dispbin = 32; //Will display this number of bins - see manipulation function
    var maxfreq = 22050; //Frequency range is 0 to 22050khz due to default sampling rate of web audio api
    var multiplier = Math.pow(maxfreq, 1/dispbin); //This value gives what you need to multiply by at each bin step to reach 22khz considering dispbin
    var smoothing = 0.80; //smoothing rate 0.8 is default
    var binwidth = 0.95; //Width of bins or graph bars. 1 is full width, 0 is hidden
    var ctx; //object in graph to fill canvas
    
    //Add coulours for canvas gradient
    var colorStop1 = '#000000'; //Black for base of plot
    var colorStop2 = '#00FF00'; //Default green for center (Changed by camera hand tracking)
    var colorStop3 = '#FF0000'; //Red for top
    //Add crossover points for canvas gradient
    var crossover1 = 1;
    var crossover2 = 0.5;
    var crossover3 = 0.1;

    createcanvas(); //Load canvas. Also load if window resised
    window.onresize = function() {createcanvas();};

    //Audio context required for any audio work. Creates and manages nodes
    var context = new AudioContext();
    
    //Audio analyser
    var analyser = context.createAnalyser();
        //Fourier transform size (Number of bins per channel?)
        analyser.fftSize = binnum * 2;
        //Smooth samples 0.8 is default
        analyser.smoothingTimeConstant = smoothing;
        //Make array to hold data with number of buckets (Array of 8bit integers)
    var frequencyData = new Uint8Array( analyser.fftSize );

    var mediaStreamSource;
        //get data from microphone
        navigator.getUserMedia = (navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia);
        navigator.getUserMedia(
            { audio: true }, 
            function( stream ) {
                mediaStreamSource = context.createMediaStreamSource( stream );
                //connect to analyser node
                mediaStreamSource.connect( analyser );
            }, 
            function( e ) {
                console.log( 'getUserMedia ' + e );
            }
        );
        
    update();

    //update plot
    function update() {
        requestAnimationFrame( update );
        //drop current audio stream into the frequency array
        analyser.getByteFrequencyData( frequencyData );
        
        var newfrequencyData = manipulate(frequencyData);
        
        ctx.clearRect( 0, 0, canvas.width, canvas.height );
        ctx.fillStyle=gradient;
        //For each bin, draw onto screen
        for( var i = 0, j = dispbin; i < j; i++ ) {
            //fill rectangle (top left X position, top left y position, width, height)
            ctx.fillRect( i * ( canvas.width / j ), canvas.height, binwidth * canvas.width / j, - newfrequencyData[ i ] * canvas.height / 255 );
    	 }
    }
    
    function manipulate(frequencyData){
        //Frequency range is 0 to 22050khz due to default sampling rate of web audio api
        var tempfrequencyData = new Uint8Array( dispbin ); //variable to hold data while being manipulated
        var binstart = 0;
        var binstop;
        //Select max frequency in each bucket. Buckets divided logarithmically based on frequency range and bucket count
        for( var i = 0; i < dispbin; i++ ) {
            binstop = Math.round(binstart * multiplier);
            if (binstop <=  binstart) { binstop++ } //Make sure it keeps moving if multiplier is too low
            var max = 0;
            for(var k = 0, l = (binstop - binstart); k < l; k++) {
                if (frequencyData[binstart + k] > max){
                    max = frequencyData[binstart + k];
                }
            }
            
            tempfrequencyData[i] = max;
            binstart = binstop;
        }
        return tempfrequencyData;
    }
    
    //Creates the canvas based on the window size. New gradient required and ctx updated
    function createcanvas(){
        canvas.width = document.documentElement.clientWidth * 0.99;
        canvas.height = document.documentElement.clientHeight * 0.98; //0.98 stops the scroll bar showing
        //get the context from the canvas to draw on
        ctx = $("#canvas").get()[0].getContext("2d");
        creategradient();
    }
    
    function creategradient(){
        //create a gradient for the fill. Note the strange offset, since the gradient is calculated based on the canvas, not the specific element we draw
        gradient = ctx.createLinearGradient(0,0,0,canvas.height);
        gradient.addColorStop(crossover1, colorStop1);
        gradient.addColorStop(crossover2, colorStop2);
        gradient.addColorStop(crossover3, colorStop3);        
    }
    
}


//toggle info on and off
$(document).ready(function() {
    $('#infobutton').click(function(event) {
        $('#info').toggle();
    });
});
