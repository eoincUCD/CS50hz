/**
 * scripts.js
 *
 * Computer Science 50
 * Final Project - CS-50hz
 *
 * Global JavaScript.
 */
 
//update graph
function graph()
{
    
    /*// check if the default naming is enabled, if not use the chrome one.
    // create the audio context (chrome only for now)
    if (! window.AudioContext) {
        if (! window.webkitAudioContext) {
            alert('no audiocontext found');
        }
        window.AudioContext = window.webkitAudioContext;
    }*/
    
    //Audio context required for any audio work. Creates and manages nodes
    var context = new AudioContext();
    //var audioBuffer;
    var sourceNode;
    //var splitter;
    //var analyser, analyser2;
    var javascriptNode;

    // get the context from the canvas to draw on
    var ctx = $("#canvas").get()[0].getContext("2d");
    console.log(ctx);

    // create a gradient for the fill. Note the strange offset, since the gradient is calculated based on the canvas, not the specific element we draw
    var gradient = ctx.createLinearGradient(0,0,0,325);
    gradient.addColorStop(1,'#000000');
    gradient.addColorStop(0.75,'#ff0000');
    gradient.addColorStop(0.25,'#ffff00');
    gradient.addColorStop(0,'#ffffff');
 
    // load the sound
    setupAudioNodes();
    loadSound("../audio/Laser.mp3");
 
    function setupAudioNodes() {
        // setup a javascript node - used for direct audio processing. (Buffersize, input channels, output channels)
        javascriptNode = context.createScriptProcessor(2048, 1, 1);
        // connect to destination, else it isn't called
        javascriptNode.connect(context.destination);
 
        // setup a analyzer - Creates an AnalyserNode, which can be used to expose audio time and frequency data and for example to create data visualisations.
        analyser = context.createAnalyser();
        //smoothingTimeConstant smooths values over time across AnalyserNode.getFloatFrequencyData/AnalyserNode.getByteFrequencyData calls.
        analyser.smoothingTimeConstant = 0.3;
        //Set size of the FFT (Fast Fourier Transform) to be used to determine the frequency domain
        analyser.fftSize = 512;
 
        // create a buffer source node
        sourceNode = context.createBufferSource();
        sourceNode.connect(analyser);
        analyser.connect(javascriptNode);
        
        // and connect to destination
        //Disables 16/03/16 - graph still working for laser
        //sourceNode.connect(context.destination);
    }
 
    // load the specified sound
    function loadSound(url) {
        var request = new XMLHttpRequest();
        request.open('GET', url, true);
        request.responseType = 'arraybuffer';
 
        // When loaded decode the data
        request.onload = function() {
 
            // decode the data
            context.decodeAudioData(request.response, function(buffer) {
                // when the audio is decoded play the sound
                playSound(buffer);
            }, onError);
        };
        request.send();
    }
 
    // when the javascript node is called
    // we use information from the analyzer node
    // to draw the volume
    javascriptNode.onaudioprocess = function() {
 
        // get the average for the first channel
        var array =  new Uint8Array(analyser.frequencyBinCount);
        analyser.getByteFrequencyData(array);
 
        // clear the current state
        ctx.clearRect(0, 0, 1000, 325);
 
        // set the fill style
        ctx.fillStyle=gradient;
        drawSpectrum(array);
    };
    
    function drawSpectrum(array) {
    for ( var i = 0; i < (array.length); i++ ){
            var value = array[i];
            ctx.fillRect(i*5,325-value,3,325);
        }
    }
 
    function playSound(buffer) {
        sourceNode.buffer = buffer;
        sourceNode.start(0);
    }
 
    // log if an error occurs
    function onError(e) {
        console.log(e);
    }

}

/*
//Update background
function maincolour(colour)
{
    // update UI
    update();
}

//Update graph colour
function graphcolour(colour)
{
    // update UI
    update();
}*/