function head()
{        
        document.addEventListener("headtrackingEvent", function(evt){ console.log(evt.x) });
        
        var videoInput = document.getElementById('inputVideo');
        var canvasInput = document.getElementById('inputCanvas');
        var htracker = new headtrackr.Tracker();
        htracker.init(videoInput, canvasInput);
        htracker.start();
        
}