/**
 * scripts.js
 *
 * Computer Science 50
 * Final Project - CS-50hz
 *
 * Global JavaScript.
 */

//<button> About CS-50hz </button>

//update graph
function graph()
{
    
    //Initial values until loaded. then canvassize will be called
    createcanvas();
    window.onresize = function() {createcanvas();};

    //Audio context required for any audio work. Creates and manages nodes
    var context = new AudioContext();
    
    //Audio analyser
    var analyser = context.createAnalyser();
        //Fourier transform size
        analyser.fftSize = 256;
        //Smooth samples
        analyser.smoothingTimeConstant = .75;
    var frequencyData = new Uint8Array( analyser.fftSize );

    
    // get the context from the canvas to draw on
    var ctx = $("#canvas").get()[0].getContext("2d");

    //create a gradient for the fill. Note the strange offset, since the gradient is calculated based on the canvas, not the specific element we draw
    var gradient = ctx.createLinearGradient(0,0,0,canvas.height);
    gradient.addColorStop(1,'#000000');
    gradient.addColorStop(0.50,'#00FF00');
    gradient.addColorStop(0,'#FF0000');
    
    var mediaStreamSource;
        navigator.getUserMedia = (navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia);
        navigator.getUserMedia(
            { audio: true }, 
            function( stream ) {
                mediaStreamSource = context.createMediaStreamSource( stream );
                mediaStreamSource.connect( analyser );
            }, 
            function( e ) {
                console.log( 'getUserMedia ' + e );
            }
    );
        
    update();
    
    //update plot
    function update() {
    	requestAnimationFrame( update );
        analyser.getByteFrequencyData( frequencyData );
    	ctx.clearRect( 0, 0, canvas.width, canvas.height );
    	ctx.fillStyle=gradient;
	    for( var i = 0, j = analyser.frequencyBinCount; i < j; i++ ) {
   	        //frequency bin count is 128 as of 26/3/16 USB webcam with microscope on Chrome and win7
   	        //fill rectangle (top left X position, top left y position, width, height)
		    ctx.fillRect( i * ( canvas.width / j ), canvas.height, .5 * canvas.width / j, - frequencyData[ i ] * canvas.height / 255 );
    	 }
	    
    }
    
    //Creates the canvas based on the window size. New gradient required and ctx updated
    function createcanvas(){
        canvas.width = document.documentElement.clientWidth;
        canvas.height = document.documentElement.clientHeight * 0.98; //0.98 stops the scroll bar showing
        ctx = $("#canvas").get()[0].getContext("2d");
        //create a gradient for the fill. Note the strange offset, since the gradient is calculated based on the canvas, not the specific element we draw
        gradient = ctx.createLinearGradient(0,0,0,canvas.height);
        gradient.addColorStop(1,'#000000');
        gradient.addColorStop(0.50,'#00FF00');
        gradient.addColorStop(0,'#ffff00');
    }

    
}


