<?php

    /**
     * config.php
     *
     * Computer Science 50
     * Final Project - CS-50hz
     *
     * Configures pages.
     */

    // display errors, warnings, and notices
    ini_set("display_errors", true);
    error_reporting(E_ALL);



?>